<?php


class AA2
{
	public function sum(Array $array)
	{
		return array_sum($array);
	}

	public function mean(Array $array)
	{
		return array_sum($array)/count($array);
	}

	public function median(Array $array)
	{		
		sort($array);
		if ((count($array) % 2) == 0) {
			$_p = round((count($array) / 2));
			return ($array[$_p]+$array[$_p+1])/2;
		}else {
			$n = round((count($array) / 2));
			return $array[$n];
		}
	}
}