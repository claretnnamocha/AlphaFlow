<?php


require_once 'DataFrame.php';

/**
 * LogisticRegression Classifier
 * @author Claret Nnamocha <devclareo@gmail.com>
 */
class LogisticRegression
{
	/**
	* @var Array $data_set Input and resultant values to be evaluated
	*/
	private $data_set = [];

	/**
	* @var float $slope The coeffiecient of the input values
	*/

	private $slope = 0;
	/**
	* @var float $intercept The coeffient of the entire dataset
	*/
	private $intercept = 0;

	/**
	* @var int $epochs Number of iterations to undergo for the training process
	*/
	private $epochs = 0;

	/**
	* @var Boolean $sgd Whether or not the SGD approach is used
	*/
	private $sgd = false;

	/**
	* @var float $alpha The Learnin rate
	*/
	private $alpha = 0.3;

	function __construct(Array $data_set, bool $sgd = false, int $epochs = 10)
	{
		if ($sgd) {
			if (!($epochs > 0))
				throw new Exception("Invalid value for epochs", 1);
			$this->sgd = true;
		}
		$this->epochs = $epochs;
		$this->check_structure($data_set);		
	}

	public function run()
	{
		$this->train();
	}

	public function set_labels(String ...$labels)
	{
		$classes = array_unique($this->data_set['y']);
		if (count($classes) != count($labels))
			throw new Exception("Number of Labels is not Equal to Number of Classess");
		$this->labels = [];
		sort($classes);
		foreach ($classes as $key => $value) {
			$this->labels[$value] = $labels[$key];
		}
	}

	public function get_labels()
	{
		return $this->labels ?? None;
	}

	/**
	* Ensuring the interity of data is matained
	* @param Array $data_set The input and output values to be evaluated
	* @return Boolean $status The valiidity of data integrity
	*/
	private function check_structure(Array $data_set) : bool 
	{
		if (count($data_set) != 2)
			throw new Exception("Invalid Data Format", 1);
		$r = ((array_keys($data_set) == ['X','Y']) or (array_keys($data_set) == ['Y','X']) or (array_keys($data_set) == ['x','y']) or (array_keys($data_set) == ['y','x']));
		if (!$r)
			throw new Exception("Invalid labels used", 1);
		$d = [];
		foreach (array_keys($data_set) as $key => $value) {
			$d[strtolower($value)] = $data_set[$value];
		}
		foreach ($d['x'] as $x) {
			if (count($x) != count($d['y']))
				throw new Exception("Incomplete Dataset", 1);
		}
		$this->data_set = $d;
		return true;
	}

	/**
	* Learning the relationhip between the data
	*/
	private function train()
	{
		$slope = [];
		$intercept = 0;
		$y_preidcted = [];
		$error = 0;
		$total_error = 0;
		for ($epoch=0; $epoch < $this->epochs; $epoch++) {
			foreach ($this->data_set['x'][0] as $index => $x) {
				$mx = 0;
				foreach ($this->data_set['x'] as $i => $_x) {
					$slope[$i] = $slope[$i] ?? 0;
					$mx += $_x[$index]*$slope[$i];
				}
				$y_preidcted[$index] = 1/(1+pow(2.71828, -($intercept + $mx)));
				$error = $this->data_set['y'][$index] - $y_preidcted[$index];
				
				$intercept = $intercept + $this->alpha * $error * $y_preidcted[$index] * (1 - $y_preidcted[$index]);
				foreach ($this->data_set['x'] as $i => $_x) {
					$slope[$i] = $slope[$i] + $this->alpha * $error * $y_preidcted[$index] * (1 - $y_preidcted[$index]) * $this->data_set['x'][$i][$index];
				}
			}
			if (!$this->sgd) {
				break;
			}
		}
		$this->slope = $slope;
		$this->intercept = $intercept;
	}

	/**
	* Speculating a result based on data given
	* @param Array $input_x 
	* @param Boolean $round 
	* @return Int $value
	*/
	public function predict(Array $input_x)
	{
		if (count($input_x) != count($this->data_set['x']))
			throw new Exception("Incomplete Dataset", 1);
		$mx = 0;
		foreach ($this->data_set['x'] as $i => $_x) {
			$mx += $input_x[$i]*$this->slope[$i];
		}
		// $value = $mx + $this->intercept;
		$value = 1/(1+pow(2.71828, -($this->intercept + $mx)));
		return $this->labels[round($value)] ?? round($value);
	}
}
#structure
$data = [
	'X' => [
			[2.7810836,1.465489372,3.396561688,1.38807019,3.06407232,7.627531214,5.332441248,6.922596716,8.675418651,7.673756466],
			[2.550537003,2.362125076,4.400293529,1.850220317,3.005305973,2.759262235,2.088626775,1.77106367,-0.2420686549,3.508563011]
		],
	'Y' => [0,0,0,0,0,1,1,1,1,1]
];


$lr = new LogisticRegression($data,true);
$lr->run();
$lr->set_labels('group 1','group 2');
$p = $lr->predict([2.7810836,2.550537003]);
// print($p);

$dataset = [
	[2.7810836,1.465489372,3.396561688,1.38807019,3.06407232,7.627531214,5.332441248,6.922596716,8.675418651,7.673756466],
	[2.550537003,2.362125076,4.400293529,1.850220317,3.005305973,2.759262235,2.088626775,1.77106367,-0.2420686549,3.508563011],
	[0,0,0,0,0,1,1,1,1,1]
];

$df = new DataFrame($dataset);
$df->set_labels('X1','X2','Y');
print($df);