<?php

/**
 * Linear Discriminant Analysis Classifier
 * @author Claret Nnamocha <devclareo@gmail.com>
 */
class LDA
{
	
	function __construct(Array $data_set)
	{
		$this->check_structure($data_set);
	}

	public function run()
	{
		
		$this->groups = $this->separate_classes($this->data_set);
		$this->train($this->groups);
	}

	private function check_structure(Array $data_set) : bool 
	{
		if (count($data_set) != 2)
			throw new Exception("Invalid Data Format");
		$r = ((array_keys($data_set) == ['X','Y']) or (array_keys($data_set) == ['Y','X']) or (array_keys($data_set) == ['x','y']) or (array_keys($data_set) == ['y','x']));
		if (!$r)
			throw new Exception("Invalid labels used");
		$d = [];
		foreach (array_keys($data_set) as $key => $value) {
			$d[strtolower($value)] = $data_set[$value];
		}
		if (count($d['x']) != count($d['y']))
			throw new Exception("Incomplete Dataset");
		$this->data_set = $d;
		return true;
	}

	private function separate_classes(Array $data_set)
	{
		$groups = [];
		$classes = array_unique($data_set['y']);
		foreach ($classes as $class_key => $class) {
			foreach(array_keys($data_set['y'],$class) as $d_key => $d_value){
				$groups[$class][] = $data_set['x'][$d_value];
			}
		}
		$this->data_set = $data_set;
		return $groups;
	}

	private function train(Array $grouped_data)
	{
		$averages = [];
		$probabilities = [];
		$square_differences = [];
		$variance = [];

		foreach ($grouped_data as $key => $value) {
			#Averages
			$averages[$key] = array_sum($value) / count($value);


			#Probabilities
			$probabilities[$key] = count($value)/count($this->data_set['x']);
		}

		#Square differences
		foreach ($grouped_data as $g_key => $in) {
			foreach ($in as $x_key => $x) {
				$square_differences[$g_key][] = pow($x - $averages[$g_key], 2);
			}
			$square_differences[$g_key] = array_sum($square_differences[$g_key]);
		}

		foreach ($square_differences as $key => $value) {
			$variance[$key] = (1/(count($grouped_data[$key]) - count($square_differences))) * array_sum($square_differences);
		}
		$this->averages = $averages;
		$this->classes = array_keys($averages);
		$this->probabilities = $probabilities;
		$this->square_differences = $square_differences;
		$this->variance = $variance;
	}

	public function predict(Float $value)
	{
		$predictions = [];
		foreach ($this->averages as $avg_key => $avg) {
			$predictions[$avg_key] = $value * ($avg/$this->variance[$avg_key]) - (pow($avg, 2)/(2*$this->variance[$avg_key])) + log(0.5);
		}
		return $this->labels[array_keys($predictions,max($predictions))[0]] ?? array_keys($predictions,max($predictions))[0];
	}

	public function set_labels(String ...$labels)
	{
		$classes = array_unique($this->data_set['y']);
		if (count($classes) != count($labels))
			throw new Exception("Number of Labels is not Equal to Number of Classess");
		$this->labels = [];
		sort($classes);
		foreach ($classes as $key => $value) {
			$this->labels[$value] = $labels[$key];
		}
	}

	public function get_labels()
	{
		return $this->labels ?? None;
	}


}

$data = [
	'x' => [
		4.667797637,5.509198779,4.702791608,5.956706641,5.738622413,5.027283325,4.805434058,4.425689143,5.009368635,5.116718815,6.370917709,2.895041947,4.666842365,5.602154638,4.902797978,5.032652964,4.083972925,4.875524106,4.732801047,5.385993407,20.74393514,21.41752855,20.57924186,20.7386947,19.44605384,18.36360265,19.90363232,19.10870851,18.18787593,19.71767611,19.09629027,20.52741312,20.63205608,19.86218119,21.34670569,20.333906,21.02714855,18.27536089,21.77371156,20.6595354
	],
	'y' => [
		0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
	]
];

$lda = new LDA($data);
$lda->run();
$lda->set_labels('group 1','group 2');
$p = $lda->predict(4.667797637);
print($p);