<?php
/**
 * NaiveBayes Classifier
 * @author Claret Nnamocha <devclareo@gmail.com>
 */
class NaiveBayes
{
	
	function __construct()
	{
		
	}

}